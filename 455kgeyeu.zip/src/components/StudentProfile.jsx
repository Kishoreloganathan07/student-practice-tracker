import { useEffect } from "react";

function StudentProfile({ name, department, year, count }) {

  useEffect(() => {
    // Store the previous browser title
    const previousTitle = document.title;

    // Update browser title
    document.title = `Practice Sessions: ${count}`;

    // Cleanup function
    return () => {
      document.title = previousTitle;
    };
  }, [count]);

  return (
    <div className="profile">
      <h2>Student Profile</h2>

      <p>
        <strong>Name:</strong> {name}
      </p>

      <p>
        <strong>Department:</strong> {department}
      </p>

      <p>
        <strong>Year:</strong> {year}
      </p>

      <p>
        <strong>Practice Sessions Completed:</strong> {count}
      </p>
    </div>
  );
}

export default StudentProfile;