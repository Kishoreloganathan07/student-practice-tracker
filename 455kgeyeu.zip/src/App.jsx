import { useState } from "react";
import Header from "./components/Header";
import StudentProfile from "./components/StudentProfile";
import Footer from "./components/Footer";
import "./App.css";

function App() {

  // Practice session state
  const [count, setCount] = useState(0);

  // Profile visibility state
  const [showProfile, setShowProfile] = useState(true);

  return (
    <div className="app">

      <Header />

      <main className="main-content">

        {showProfile && (
          <StudentProfile
            name="Anu"
            department="CSE"
            year="3rd Year"
            count={count}
          />
        )}

        <div className="buttons">

          <button onClick={() => setCount(count + 1)}>
            Complete Practice
          </button>

          <button onClick={() => setCount(0)}>
            Reset
          </button>

          <button onClick={() => setShowProfile(!showProfile)}>
            {showProfile ? "Hide Profile" : "Show Profile"}
          </button>

        </div>

      </main>

      <Footer />

    </div>
  );
}

export default App;